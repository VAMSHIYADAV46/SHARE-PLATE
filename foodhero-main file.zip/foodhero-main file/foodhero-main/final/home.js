


document.addEventListener('DOMContentLoaded', function() {

    document.getElementById('donate').addEventListener('click',async  function() {
        window.location.href = 'donatefood.html';
        });

        document.getElementById('recieve').addEventListener('click',async  function() {
            window.location.href = 'recieve_food.html';
            });

    })